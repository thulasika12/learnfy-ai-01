-- ============================================================
-- Learnfy AI — Idempotent sample data
-- ============================================================
-- Sample passwords:
--   admin@learnfy.ai   -> Admin@123
--   teacher@learnfy.ai -> Teacher@123
--   student@learnfy.ai -> Student@123
-- Change or remove these accounts before a public deployment.
-- ============================================================

USE learnfy_ai;

INSERT INTO users (name, email, password, role, is_verified_teacher, is_active)
VALUES
  ('Learnfy Admin', 'admin@learnfy.ai', '$2b$12$b7194G7JJuoZtXhsaqUW2ezk1DYsTJrbSqvySjWvHhHuZniUHdo9q', 'admin', TRUE, TRUE),
  ('Priya Teacher', 'teacher@learnfy.ai', '$2b$12$ec8YlotsSdbZ1uB62/hKwOhCKFbyF8k2vdZ7GMspOyfvCFN3TVnHS', 'teacher', TRUE, TRUE),
  ('Rahul Student', 'student@learnfy.ai', '$2b$12$lRpnwAlLEo3xBc1Y4HAnUukRqpCIGeCeEwC8TQuy3gl2j.bUO0mH2', 'student', FALSE, TRUE)
ON DUPLICATE KEY UPDATE
  name = VALUES(name),
  role = VALUES(role),
  is_verified_teacher = VALUES(is_verified_teacher),
  is_active = TRUE;

INSERT INTO study_groups (name, description, creator_id)
SELECT 'Physics Warriors', 'Group for physics preparation and doubt discussion', u.id
FROM users AS u
WHERE u.email = 'teacher@learnfy.ai'
  AND NOT EXISTS (SELECT 1 FROM study_groups WHERE name = 'Physics Warriors');

INSERT INTO study_groups (name, description, creator_id)
SELECT 'Data Structures Study Circle', 'Weekly DSA problem-solving sessions', u.id
FROM users AS u
WHERE u.email = 'student@learnfy.ai'
  AND NOT EXISTS (SELECT 1 FROM study_groups WHERE name = 'Data Structures Study Circle');

INSERT IGNORE INTO group_members (group_id, user_id, role)
SELECT
  g.id,
  u.id,
  CASE WHEN u.email = 'teacher@learnfy.ai' THEN 'admin' ELSE 'member' END
FROM study_groups AS g
JOIN users AS u ON u.email IN ('teacher@learnfy.ai', 'student@learnfy.ai')
WHERE g.name = 'Physics Warriors';

INSERT IGNORE INTO group_members (group_id, user_id, role)
SELECT g.id, u.id, 'admin'
FROM study_groups AS g
JOIN users AS u ON u.email = 'student@learnfy.ai'
WHERE g.name = 'Data Structures Study Circle';

-- Keep every group creator as its admin even when this seed is run again.
UPDATE group_members AS gm
JOIN study_groups AS sg ON sg.id = gm.group_id AND sg.creator_id = gm.user_id
SET gm.role = 'admin';
