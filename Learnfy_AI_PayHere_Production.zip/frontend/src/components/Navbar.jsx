import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  FiBell,
  FiChevronDown,
  FiGlobe,
  FiLogOut,
  FiMenu,
  FiMoon,
  FiSettings,
  FiSun,
  FiUser,
} from "react-icons/fi";
import { motion, AnimatePresence } from "framer-motion";

import { useAuth } from "../hooks/useAuth";
import { usePreferences } from "../hooks/usePreferences";

export default function Navbar({ onToggleSidebar, showSidebarToggle = false }) {
  const { user, isAuthenticated, logout } = useAuth();
  const { theme, toggleTheme, language, setLanguage, t } = usePreferences();
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <header className="sticky top-0 z-40 bg-white/80 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-100 dark:border-slate-700">
      <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {showSidebarToggle && (
            <button
              onClick={onToggleSidebar}
              className="md:hidden p-2 rounded-lg hover:bg-slate-100 text-slate-600"
            >
              <FiMenu size={22} />
            </button>
          )}
          <Link to="/" className="flex items-center gap-2">
            <img src="/images/logo.png" alt="Learnfy AI" className="w-9 h-9 rounded-lg object-cover" />
            <span className="font-extrabold text-lg tracking-tight">
              <span className="text-slate-800">Learn</span>
              <span className="bg-clip-text text-transparent bg-brand-gradient">fy AI</span>
            </span>
          </Link>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={toggleTheme}
            aria-label={theme === "dark" ? t("theme.switchToLight") : t("theme.switchToDark")}
            title={theme === "dark" ? t("theme.switchToLight") : t("theme.switchToDark")}
            className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
          >
            {theme === "dark" ? <FiSun size={19} /> : <FiMoon size={19} />}
          </button>

          <label className="relative hidden items-center sm:flex">
            <FiGlobe className="pointer-events-none absolute left-2.5 text-slate-400" />
            <select
              value={language}
              onChange={(event) => setLanguage(event.target.value)}
              aria-label={t("settings.language")}
              className="rounded-lg border border-slate-200 bg-white py-2 pl-8 pr-2 text-sm text-slate-700 outline-none dark:border-slate-600 dark:bg-slate-800 dark:text-slate-100"
            >
              <option value="en">EN</option>
              <option value="ta">தமிழ்</option>
              <option value="si">සිංහල</option>
            </select>
          </label>

          {!isAuthenticated ? (
            <div className="hidden md:flex items-center gap-6">
              <Link to="/notes" className="text-slate-600 hover:text-primary-600 font-medium">
                {t("nav.exploreNotes")}
              </Link>
              <Link to="/resources" className="text-slate-600 hover:text-primary-600 font-medium">
                {t("nav.resources")}
              </Link>
              <Link to="/pricing" className="text-slate-600 hover:text-primary-600 font-medium">
                {t("nav.pricing")}
              </Link>
              <Link to="/login" className="text-slate-600 hover:text-primary-600 font-medium">
                {t("nav.login")}
              </Link>
              <Link to="/register" className="btn-primary">
                {t("nav.getStarted")}
              </Link>
            </div>
          ) : (
            <>
            <button className="p-2 rounded-lg hover:bg-slate-100 text-slate-500 relative">
              <FiBell size={20} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-accent-500" />
            </button>

            <div className="relative">
              <button
                onClick={() => setMenuOpen((o) => !o)}
                className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-xl hover:bg-slate-100"
              >
                <img
                  src={user?.profile_image || "https://api.dicebear.com/7.x/initials/svg?seed=" + user?.name}
                  alt="avatar"
                  className="w-8 h-8 rounded-full object-cover border border-slate-200"
                />
                <span className="hidden sm:block text-sm font-semibold text-slate-700">{user?.name}</span>
                <FiChevronDown className="text-slate-400" size={16} />
              </button>

              <AnimatePresence>
                {menuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    className="absolute right-0 mt-2 w-48 glass-card bg-white p-2"
                  >
                    <Link
                      to="/profile"
                      onClick={() => setMenuOpen(false)}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-50 text-sm text-slate-700"
                    >
                      <FiUser /> {t("nav.profile")}
                    </Link>
                    <Link
                      to="/settings"
                      onClick={() => setMenuOpen(false)}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-50 text-sm text-slate-700"
                    >
                      <FiSettings /> {t("nav.settings")}
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-red-50 text-sm text-red-600"
                    >
                      <FiLogOut /> {t("nav.logout")}
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
