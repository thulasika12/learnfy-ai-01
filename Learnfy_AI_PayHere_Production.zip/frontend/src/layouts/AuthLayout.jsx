import { Link, Outlet } from "react-router-dom";
import { motion } from "framer-motion";
import { FiMoon, FiSun } from "react-icons/fi";

import { usePreferences } from "../hooks/usePreferences";

export default function AuthLayout() {
  const { theme, toggleTheme, language, setLanguage, t } = usePreferences();

  return (
    <div className="min-h-screen grid md:grid-cols-2 bg-slate-50 dark:bg-slate-950">
      {/* Left branding panel */}
      <div className="hidden md:flex flex-col justify-between bg-brand-gradient text-white p-12 relative overflow-hidden">
        <motion.div
          className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-white/10"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ repeat: Infinity, duration: 6 }}
        />
        <motion.div
          className="absolute bottom-0 left-0 w-56 h-56 rounded-full bg-white/10"
          animate={{ scale: [1, 1.15, 1] }}
          transition={{ repeat: Infinity, duration: 8 }}
        />

        <Link to="/" className="flex items-center gap-2 z-10">
          <img src="/images/logo.png" alt="Learnfy AI" className="w-10 h-10 rounded-lg" />
          <span className="font-extrabold text-xl">Learnfy AI</span>
        </Link>

        <div className="z-10">
          <h1 className="text-4xl font-extrabold leading-tight mb-4">
            Learn Smarter with<br /> AI-Powered Study Support
          </h1>
          <p className="text-white/80 max-w-md">
            Share notes, resolve doubts instantly, generate quizzes, and build a personalized
            study plan — all powered by AI.
          </p>
        </div>

        <p className="text-white/60 text-sm z-10">Learn • Connect • Grow</p>
      </div>

      {/* Right form panel */}
      <div className="relative flex items-center justify-center p-6 md:p-12">
        <div className="absolute right-4 top-4 flex items-center gap-2">
          <button
            type="button"
            onClick={toggleTheme}
            title={theme === "dark" ? t("theme.switchToLight") : t("theme.switchToDark")}
            className="rounded-lg border border-slate-200 bg-white p-2 text-slate-600 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200"
          >
            {theme === "dark" ? <FiSun /> : <FiMoon />}
          </button>
          <select
            value={language}
            onChange={(event) => setLanguage(event.target.value)}
            aria-label={t("settings.language")}
            className="rounded-lg border border-slate-200 bg-white px-2 py-2 text-sm text-slate-700 outline-none dark:border-slate-600 dark:bg-slate-800 dark:text-slate-100"
          >
            <option value="en">EN</option>
            <option value="ta">தமிழ்</option>
            <option value="si">සිංහල</option>
          </select>
        </div>
        <div className="w-full max-w-md">
          <div className="md:hidden flex items-center gap-2 mb-8 justify-center">
            <img src="/images/logo.png" alt="Learnfy AI" className="w-9 h-9 rounded-lg" />
            <span className="font-extrabold text-lg text-slate-800">Learnfy AI</span>
          </div>
          <Outlet />
        </div>
      </div>
    </div>
  );
}
