import axios from "axios";

export const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

const api = axios.create({
  baseURL: BASE_URL,
});

// Attach JWT token to every request if present
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("learnfy_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

const clearSession = () => {
  localStorage.removeItem("learnfy_token");
  localStorage.removeItem("learnfy_refresh_token");
  localStorage.removeItem("learnfy_user");
};

let refreshRequest = null;

// Retry one failed request after rotating the refresh token.
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    const noRefreshPaths = [
      "/auth/login",
      "/auth/register",
      "/auth/refresh",
      "/auth/logout",
      "/auth/forgot-password",
      "/auth/reset-password",
    ];
    const skipRefresh = noRefreshPaths.some((path) => originalRequest?.url?.startsWith(path));
    const refresh = localStorage.getItem("learnfy_refresh_token");

    if (error.response?.status === 401 && !originalRequest?._retry && !skipRefresh && refresh) {
      originalRequest._retry = true;
      try {
        refreshRequest ||= axios
          .post(`${BASE_URL}/auth/refresh`, { refresh_token: refresh })
          .then((res) => {
            localStorage.setItem("learnfy_token", res.data.access_token);
            localStorage.setItem("learnfy_refresh_token", res.data.refresh_token);
            localStorage.setItem("learnfy_user", JSON.stringify(res.data.user));
            return res.data.access_token;
          })
          .finally(() => {
            refreshRequest = null;
          });

        const newToken = await refreshRequest;
        originalRequest.headers.Authorization = `Bearer ${newToken}`;
        return api(originalRequest);
      } catch {
        clearSession();
      }
    } else if (error.response?.status === 401 && !skipRefresh) {
      clearSession();
    }

    if (error.response?.status === 401 && !window.location.pathname.startsWith("/login")) {
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------
export const registerUser = (data) => api.post("/auth/register", data);
export const loginUser = (data) => api.post("/auth/login", data);
export const forgotPassword = (data) => api.post("/auth/forgot-password", data);
export const resetPassword = (data) => api.post("/auth/reset-password", data);
export const refreshToken = (data) => api.post("/auth/refresh", data);
export const logoutUser = (data) => api.post("/auth/logout", data);
export const changePassword = (data) => api.post("/auth/change-password", data);

// ---------------------------------------------------------------------------
// Payments
// ---------------------------------------------------------------------------
export const getPaymentPlans = () => api.get("/payments/plans");
export const createPaymentCheckout = (data) => api.post("/payments/checkout", data);
export const getMyPayments = () => api.get("/payments/me");
export const getPaymentStatus = (orderId) => api.get(`/payments/status/${encodeURIComponent(orderId)}`);
export const getAdminTransactions = () => api.get("/payments/admin/transactions");

// ---------------------------------------------------------------------------
// Users
// ---------------------------------------------------------------------------
export const getProfile = () => api.get("/users/profile");
export const updateProfile = (data) => api.put("/users/profile", data);
export const uploadAvatar = (formData) => api.post("/users/profile/avatar", formData);
export const deleteAccount = (data) => api.delete("/users/account", { data });

// ---------------------------------------------------------------------------
// Notes
// ---------------------------------------------------------------------------
export const getNotes = (params) => api.get("/notes/", { params });
export const getNote = (id) => api.get(`/notes/${id}`);
export const uploadNote = (formData) => api.post("/notes/", formData);
export const updateNote = (id, data) => api.put(`/notes/${id}`, data);
export const deleteNote = (id) => api.delete(`/notes/${id}`);
export const toggleLike = (id) => api.post(`/notes/${id}/like`);
export const toggleBookmark = (id) => api.post(`/notes/${id}/bookmark`);

// ---------------------------------------------------------------------------
// Comments
// ---------------------------------------------------------------------------
export const getComments = (noteId) => api.get(`/comments/${noteId}`);
export const postComment = (data) => api.post("/comments/", data);

// ---------------------------------------------------------------------------
// Study Groups
// ---------------------------------------------------------------------------
export const getGroups = () => api.get("/groups/");
export const createGroup = (data) => api.post("/groups/create", data);
export const deleteGroup = (id) => api.delete(`/groups/${id}`);
export const joinGroup = (id) => api.post(`/groups/${id}/join`);
export const leaveGroup = (id) => api.post(`/groups/${id}/leave`);
export const getJoinRequests = (groupId) => api.get(`/groups/${groupId}/join-requests`);
export const approveJoinRequest = (groupId, requestId) =>
  api.post(`/groups/${groupId}/join-requests/${requestId}/approve`);
export const rejectJoinRequest = (groupId, requestId) =>
  api.post(`/groups/${groupId}/join-requests/${requestId}/reject`);
export const getDiscussions = (groupId) => api.get(`/groups/${groupId}/discussions`);
export const postDiscussion = (groupId, data) => api.post(`/groups/${groupId}/discussions`, data);

// ---------------------------------------------------------------------------
// AI
// ---------------------------------------------------------------------------
export const aiChat = (data) => api.post("/ai/chat", data);
export const aiSummarize = (data) => api.post("/ai/summarize", data);
export const aiSummarizeFile = (formData) => api.post("/ai/summarize-file", formData);
export const aiGenerateQuiz = (data) => api.post("/ai/generate-quiz", data);
export const aiSubmitQuiz = (data) => api.post("/ai/quiz/submit", data);
export const aiStudyPlan = (data) => api.post("/ai/study-plan", data);
export const aiFlashcards = (data) => api.post("/ai/flashcards", data);

// ---------------------------------------------------------------------------
// Complete flashcard system
// ---------------------------------------------------------------------------
export const generateFlashcards = (data) => api.post("/flashcards/generate", data);
export const generateFlashcardsFromText = (data) => api.post("/flashcards/generate-from-text", data);
export const generateFlashcardsFromNote = (data) => api.post("/flashcards/generate-from-note", data);
export const generateFlashcardsFromFile = (path, data, onUploadProgress) => api.post(path, data, { onUploadProgress });
export const saveFlashcardSet = (data) => api.post("/flashcards/sets", data);
export const getFlashcardSets = (params) => api.get("/flashcards/sets", { params });
export const getFlashcardSet = (id) => api.get(`/flashcards/sets/${id}`);
export const updateFlashcardSet = (id, data) => api.put(`/flashcards/sets/${id}`, data);
export const deleteFlashcardSet = (id) => api.delete(`/flashcards/sets/${id}`);
export const toggleFlashcardSetFavourite = (id) => api.patch(`/flashcards/sets/${id}/favourite`);
export const toggleFlashcardFavourite = (id) => api.patch(`/flashcards/cards/${id}/favourite`);
export const uploadFlashcardImage = (id, data, onUploadProgress) => api.post(`/flashcards/cards/${id}/image`, data, { onUploadProgress });
export const saveFlashcardStudySession = (id, data) => api.post(`/flashcards/sets/${id}/study-sessions`, data);
export const getFlashcardStudySessions = (id) => api.get(`/flashcards/sets/${id}/study-sessions`);
export const shareFlashcardSet = (id, data) => api.post(`/flashcards/sets/${id}/share`, data);
export const unshareFlashcardSet = (id) => api.delete(`/flashcards/sets/${id}/share`);
export const getSharedFlashcardSet = (token) => api.get(`/flashcards/shared/${encodeURIComponent(token)}`);
export const getFlashcardStats = () => api.get("/flashcards/dashboard/stats");
export const getFlashcardReminder = () => api.get("/flashcards/reminders");
export const updateFlashcardReminder = (data) => api.put("/flashcards/reminders", data);
export const flashcardExportUrl = (id, format) => `${BASE_URL}/flashcards/sets/${id}/export/${format}`;
export const getChatHistory = (params) => api.get("/chat/history", { params });

// ---------------------------------------------------------------------------
// Teacher resources
// ---------------------------------------------------------------------------
export const getResources = () => api.get("/resources/");
export const uploadResource = (formData) => api.post("/resources/", formData);
export const deleteResource = (id) => api.delete(`/resources/${id}`);

// ---------------------------------------------------------------------------
// Admin
// ---------------------------------------------------------------------------
export const getAllUsers = () => api.get("/admin/users");
export const deleteUser = (id) => api.delete(`/admin/users/${id}`);
export const verifyTeacher = (id) => api.put(`/admin/users/${id}/verify-teacher`);
export const deactivateUser = (id) => api.put(`/admin/users/${id}/deactivate`);
export const getReportedNotes = () => api.get("/admin/notes/reported");
export const getStatistics = () => api.get("/admin/statistics");

export default api;
