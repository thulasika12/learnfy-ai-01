import { useState } from "react";
import toast from "react-hot-toast";
import { FiUsers, FiFileText, FiFlag, FiShield, FiTrash2, FiCheckCircle } from "react-icons/fi";

import useFetch from "../../hooks/useFetch";
import { getAllUsers, getStatistics, getReportedNotes, deleteUser, verifyTeacher } from "../../services/api";
import Card from "../../components/Card";
import Loader from "../../components/Loader";

export default function AdminDashboard() {
  const { data: stats, loading: statsLoading } = useFetch(() => getStatistics(), []);
  const { data: users, loading: usersLoading, refetch: refetchUsers } = useFetch(() => getAllUsers(), []);
  const { data: reportedNotes, loading: reportedLoading } = useFetch(() => getReportedNotes(), []);
  const [busyId, setBusyId] = useState(null);

  const handleVerify = async (id) => {
    setBusyId(id);
    try {
      await verifyTeacher(id);
      toast.success("Teacher verified");
      refetchUsers();
    } catch (err) {
      toast.error(err.response?.data?.detail || "Could not verify teacher");
    } finally {
      setBusyId(null);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this user permanently?")) return;
    setBusyId(id);
    try {
      await deleteUser(id);
      toast.success("User removed");
      refetchUsers();
    } catch (err) {
      toast.error(err.response?.data?.detail || "Could not delete user");
    } finally {
      setBusyId(null);
    }
  };

  const statCards = [
    { label: "Total Users", value: stats?.total_users, icon: FiUsers, color: "bg-primary-50 text-primary-600" },
    { label: "Students", value: stats?.total_students, icon: FiUsers, color: "bg-accent-500/10 text-accent-600" },
    { label: "Teachers", value: stats?.total_teachers, icon: FiUsers, color: "bg-purple-50 text-purple-600" },
    { label: "Total Notes", value: stats?.total_notes, icon: FiFileText, color: "bg-emerald-50 text-emerald-600" },
    { label: "Study Groups", value: stats?.total_study_groups, icon: FiUsers, color: "bg-amber-50 text-amber-600" },
    { label: "Reported Notes", value: stats?.reported_notes, icon: FiFlag, color: "bg-red-50 text-red-600" },
  ];

  return (
    <div className="space-y-6">
      <h1 className="page-title flex items-center gap-2">
        <FiShield className="text-primary-600" /> Admin Dashboard
      </h1>

      {statsLoading ? (
        <Loader />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {statCards.map((s) => (
            <Card key={s.label} className="flex items-center gap-4">
              <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${s.color}`}>
                <s.icon size={20} />
              </div>
              <div>
                <p className="text-xs text-slate-500">{s.label}</p>
                <p className="text-xl font-bold text-slate-800">{s.value ?? "—"}</p>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Card>
        <h3 className="font-bold text-slate-800 mb-4">Manage Users</h3>
        {usersLoading ? (
          <Loader />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-400 border-b border-slate-100">
                  <th className="pb-2 font-medium">Name</th>
                  <th className="pb-2 font-medium">Email</th>
                  <th className="pb-2 font-medium">Role</th>
                  <th className="pb-2 font-medium">Status</th>
                  <th className="pb-2 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users?.map((u) => (
                  <tr key={u.id}>
                    <td className="py-3 font-medium text-slate-700">{u.name}</td>
                    <td className="py-3 text-slate-500">{u.email}</td>
                    <td className="py-3 capitalize text-slate-500">{u.role}</td>
                    <td className="py-3">
                      {u.role === "teacher" && (
                        <span
                          className={`text-xs font-semibold px-2 py-1 rounded-full ${
                            u.is_verified_teacher ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"
                          }`}
                        >
                          {u.is_verified_teacher ? "Verified" : "Unverified"}
                        </span>
                      )}
                    </td>
                    <td className="py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {u.role === "teacher" && !u.is_verified_teacher && (
                          <button
                            disabled={busyId === u.id}
                            onClick={() => handleVerify(u.id)}
                            className="p-1.5 rounded-lg hover:bg-emerald-50 text-emerald-600"
                            title="Verify teacher"
                          >
                            <FiCheckCircle size={16} />
                          </button>
                        )}
                        <button
                          disabled={busyId === u.id}
                          onClick={() => handleDelete(u.id)}
                          className="p-1.5 rounded-lg hover:bg-red-50 text-red-500"
                          title="Delete user"
                        >
                          <FiTrash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card>
        <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
          <FiFlag className="text-red-500" /> Reported Notes
        </h3>
        {reportedLoading ? (
          <Loader />
        ) : reportedNotes?.length ? (
          <ul className="divide-y divide-slate-100">
            {reportedNotes.map((n) => (
              <li key={n.id} className="py-3 flex items-center justify-between text-sm">
                <span className="text-slate-700 font-medium">{n.title}</span>
                <span className="text-slate-400">{n.subject}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-slate-400">No reported notes right now 🎉</p>
        )}
      </Card>
    </div>
  );
}
