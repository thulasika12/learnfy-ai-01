import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { FiArrowLeft, FiExternalLink, FiLock } from "react-icons/fi";
import toast from "react-hot-toast";

import Button from "../../components/Button";
import Loader from "../../components/Loader";
import { createPaymentCheckout, getPaymentPlans } from "../../services/api";
import { usePreferences } from "../../hooks/usePreferences";

function postToPayHere(actionUrl, fields) {
  const form = document.createElement("form");
  form.method = "POST";
  form.action = actionUrl;
  Object.entries(fields).forEach(([name, value]) => {
    const input = document.createElement("input");
    input.type = "hidden";
    input.name = name;
    input.value = value;
    form.appendChild(input);
  });
  document.body.appendChild(form);
  form.submit();
}

export default function Checkout() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { t } = usePreferences();
  const planCode = searchParams.get("plan");
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ phone: "", address: "", city: "", country: "Sri Lanka" });

  useEffect(() => {
    getPaymentPlans().then((res) => {
      const selected = res.data.find((item) => item.code === planCode && item.code !== "free");
      if (!selected) navigate("/pricing", { replace: true });
      setPlan(selected);
    }).catch(() => toast.error(t("payments.loadError"))).finally(() => setLoading(false));
  }, [navigate, planCode, t]);

  const submit = async (event) => {
    event.preventDefault();
    setSubmitting(true);
    try {
      const response = await createPaymentCheckout({ plan_code: plan.code, ...form });
      postToPayHere(response.data.action_url, response.data.fields);
    } catch (error) {
      toast.error(error.response?.data?.detail || t("payments.checkoutError"));
      setSubmitting(false);
    }
  };

  if (loading || !plan) return <Loader />;
  return (
    <div className="mx-auto max-w-4xl">
      <Link to="/pricing" className="mb-6 inline-flex items-center gap-2 text-sm font-semibold text-primary-600"><FiArrowLeft /> {t("payments.backToPlans")}</Link>
      <div className="grid overflow-hidden rounded-lg border border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-900 lg:grid-cols-[.85fr_1.15fr]">
        <aside className="bg-slate-900 p-7 text-white lg:p-9">
          <p className="text-sm font-semibold text-cyan-300">{t("payments.orderSummary")}</p>
          <h1 className="mt-3 text-2xl font-black">{plan.name}</h1>
          <p className="mt-5 text-4xl font-black">LKR {Number(plan.amount).toLocaleString()}</p>
          <p className="mt-1 text-sm text-slate-300">{plan.duration_days} {t("payments.daysAccess")}</p>
          <div className="mt-8 border-t border-slate-700 pt-6 text-sm leading-6 text-slate-300"><FiLock className="mb-3 text-emerald-400" />{t("payments.cardOnPayHere")}</div>
        </aside>
        <form onSubmit={submit} className="space-y-5 p-7 lg:p-9">
          <div><h2 className="text-xl font-bold text-slate-900 dark:text-white">{t("payments.billingDetails")}</h2><p className="mt-1 text-sm text-slate-500">{t("payments.billingSubtitle")}</p></div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-200">{t("payments.phone")}<input required type="tel" className="input-field mt-1" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></label>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-200">{t("payments.address")}<input required className="input-field mt-1" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></label>
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-200">{t("payments.city")}<input required className="input-field mt-1" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></label>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-200">{t("payments.country")}<input required className="input-field mt-1" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} /></label>
          </div>
          <Button type="submit" loading={submitting} className="w-full">{t("payments.continuePayHere")} <FiExternalLink /></Button>
          <p className="text-center text-xs text-slate-500">{t("payments.noCardStorage")}</p>
        </form>
      </div>
    </div>
  );
}
