import { useState } from "react";
import { FiSearch } from "react-icons/fi";
import toast from "react-hot-toast";

import useFetch from "../../hooks/useFetch";
import { getNotes, toggleLike, toggleBookmark } from "../../services/api";
import NoteCard from "../../components/NoteCard";
import Loader from "../../components/Loader";

const subjects = ["All", "Mathematics", "Physics", "Chemistry", "Biology", "Computer Science", "English"];

export default function NotesList() {
  const [search, setSearch] = useState("");
  const [subject, setSubject] = useState("All");

  const { data: notes, loading, setData } = useFetch(
    () => getNotes({ search: search || undefined, subject: subject === "All" ? undefined : subject }),
    [search, subject]
  );

  const handleLike = async (id) => {
    try {
      const res = await toggleLike(id);
      setData((prev) =>
        prev.map((n) =>
          n.id === id
            ? { ...n, is_liked: res.data.liked, likes_count: n.likes_count + (res.data.liked ? 1 : -1) }
            : n
        )
      );
    } catch {
      toast.error("Please log in to like notes");
    }
  };

  const handleBookmark = async (id) => {
    try {
      const res = await toggleBookmark(id);
      setData((prev) => prev.map((n) => (n.id === id ? { ...n, is_bookmarked: res.data.bookmarked } : n)));
      toast.success(res.data.bookmarked ? "Bookmarked" : "Bookmark removed");
    } catch {
      toast.error("Please log in to bookmark notes");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="page-title">Explore Notes</h1>
      </div>

      <div className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            className="input-field pl-10"
            placeholder="Search notes by title or description..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <select
          className="input-field md:w-56"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
        >
          {subjects.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <Loader />
      ) : notes?.length ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {notes.map((note) => (
            <NoteCard key={note.id} note={note} onLike={handleLike} onBookmark={handleBookmark} />
          ))}
        </div>
      ) : (
        <div className="text-center text-slate-500 py-16">No notes found. Try a different search.</div>
      )}
    </div>
  );
}
