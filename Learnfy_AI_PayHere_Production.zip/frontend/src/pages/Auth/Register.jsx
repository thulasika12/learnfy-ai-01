import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { FiUser, FiMail, FiLock } from "react-icons/fi";

import { useAuth } from "../../hooks/useAuth";
import { usePreferences } from "../../hooks/usePreferences";
import Button from "../../components/Button";

export default function Register() {
  const { register } = useAuth();
  const { t } = usePreferences();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "", role: "student" });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.name || form.name.length < 2) e.name = "Enter your full name";
    if (!form.email) e.email = "Email is required";
    if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/.test(form.password)) e.password = "Use 8+ characters with uppercase, lowercase, number and special character";
    if (form.password !== form.confirmPassword) e.confirmPassword = "Passwords do not match";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      const registeredUser = await register(form.name, form.email, form.password, form.confirmPassword, form.role);
      toast.success(t("auth.accountCreated"));
      navigate(registeredUser.role === "teacher" ? "/teacher/dashboard" : "/dashboard");
    } catch (err) {
      toast.error(err.response?.data?.detail || t("auth.registrationFailed"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-slate-800 mb-1">{t("auth.createTitle")}</h2>
      <p className="text-slate-500 mb-6">{t("auth.createSubtitle")}</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-sm font-medium text-slate-600 mb-1 block">{t("auth.fullName")}</label>
          <div className="relative">
            <FiUser className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              className="input-field pl-10"
              placeholder="Jane Doe"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </div>
          {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name}</p>}
        </div>

        <div>
          <label className="text-sm font-medium text-slate-600 mb-1 block">{t("auth.email")}</label>
          <div className="relative">
            <FiMail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="email"
              className="input-field pl-10"
              placeholder="you@example.com"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
          </div>
          {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email}</p>}
        </div>

        <div>
          <label className="text-sm font-medium text-slate-600 mb-1 block">{t("auth.password")}</label>
          <div className="relative">
            <FiLock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="password"
              className="input-field pl-10"
              placeholder="8+ chars: Aa1@"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
          </div>
          {errors.password && <p className="text-xs text-red-500 mt-1">{errors.password}</p>}
        </div>

        <div>
          <label className="text-sm font-medium text-slate-600 mb-1 block">{t("auth.confirmPassword")}</label>
          <div className="relative">
            <FiLock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="password"
              className="input-field pl-10"
              placeholder="Re-enter password"
              value={form.confirmPassword}
              onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
            />
          </div>
          {errors.confirmPassword && <p className="text-xs text-red-500 mt-1">{errors.confirmPassword}</p>}
        </div>

        <div>
          <label className="text-sm font-medium text-slate-600 mb-2 block">{t("auth.rolePrompt")}</label>
          <div className="grid grid-cols-2 gap-3">
            {["student", "teacher"].map((role) => (
              <button
                type="button"
                key={role}
                onClick={() => setForm({ ...form, role })}
                className={`py-2.5 rounded-xl border font-semibold capitalize transition-colors ${
                  form.role === role
                    ? "bg-brand-gradient text-white border-transparent"
                    : "border-slate-200 text-slate-600 hover:bg-slate-50"
                }`}
              >
                {t(`auth.${role}`)}
              </button>
            ))}
          </div>
        </div>

        <Button type="submit" className="w-full" loading={loading}>
          {t("auth.createAccount")}
        </Button>
      </form>

      <p className="text-center text-sm text-slate-500 mt-6">
        {t("auth.haveAccount")}{" "}
        <Link to="/login" className="text-primary-600 font-semibold hover:underline">
          {t("auth.login")}
        </Link>
      </p>
    </div>
  );
}
