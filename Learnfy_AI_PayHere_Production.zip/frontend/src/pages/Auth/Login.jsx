import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import toast from "react-hot-toast";
import { FiMail, FiLock } from "react-icons/fi";

import { useAuth } from "../../hooks/useAuth";
import { usePreferences } from "../../hooks/usePreferences";
import Button from "../../components/Button";

export default function Login() {
  const { login } = useAuth();
  const { t } = usePreferences();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.email) e.email = t("auth.emailRequired");
    if (!form.password) e.password = t("auth.passwordRequired");
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      const loggedInUser = await login(form.email, form.password);
      toast.success(t("auth.welcome"));
      const dashboardByRole = {
        admin: "/admin/dashboard",
        teacher: "/teacher/dashboard",
        student: "/dashboard",
      };
      const queryNext = new URLSearchParams(location.search).get("next");
      const safeNext = queryNext?.startsWith("/") && !queryNext.startsWith("//") ? queryNext : null;
      const redirectTo = safeNext || location.state?.from?.pathname || dashboardByRole[loggedInUser.role] || "/dashboard";
      navigate(redirectTo, { replace: true });
    } catch (err) {
      toast.error(err.response?.data?.detail || t("auth.invalidLogin"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-slate-800 mb-1">{t("auth.welcomeBack")}</h2>
      <p className="text-slate-500 mb-6">{t("auth.loginSubtitle")}</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-sm font-medium text-slate-600 mb-1 block">{t("auth.email")}</label>
          <div className="relative">
            <FiMail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="email"
              className="input-field pl-10"
              placeholder="you@example.com"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
          </div>
          {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email}</p>}
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-sm font-medium text-slate-600">{t("auth.password")}</label>
            <Link to="/forgot-password" className="text-xs text-primary-600 hover:underline">
              {t("auth.forgotPassword")}
            </Link>
          </div>
          <div className="relative">
            <FiLock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="password"
              className="input-field pl-10"
              placeholder="••••••••"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
          </div>
          {errors.password && <p className="text-xs text-red-500 mt-1">{errors.password}</p>}
        </div>

        <Button type="submit" className="w-full" loading={loading}>
          {t("auth.login")}
        </Button>
      </form>

      <p className="text-center text-sm text-slate-500 mt-6">
        {t("auth.noAccount")}{" "}
        <Link to="/register" className="text-primary-600 font-semibold hover:underline">
          {t("auth.signUp")}
        </Link>
      </p>
    </div>
  );
}
