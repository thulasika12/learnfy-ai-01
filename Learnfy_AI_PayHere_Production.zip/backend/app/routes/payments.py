"""Secure PayHere checkout, callback, account, and admin routes."""
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session, joinedload

from app.config.database import get_db
from app.config.settings import settings
from app.models.payment import Payment, Subscription
from app.models.user import User
from app.schemas.payment_schema import (
    AdminPaymentOut,
    CheckoutRequest,
    CheckoutResponse,
    MyPaymentsOut,
    PaymentOut,
    PaymentStatusOut,
    PlanOut,
    SubscriptionOut,
)
from app.services.payhere_service import (
    PLANS,
    STATUS_MAP,
    action_url,
    checkout_hash,
    formatted_amount,
    validate_configuration,
    verify_callback_signature,
)
from app.utils.dependencies import get_current_user, require_admin

router = APIRouter(prefix="/payments", tags=["Payments"])


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def as_utc(value: datetime) -> datetime:
    return value if value.tzinfo else value.replace(tzinfo=timezone.utc)


def current_subscription(db: Session, user_id: int) -> Subscription | None:
    now = utcnow()
    candidates = (
        db.query(Subscription)
        .filter(Subscription.user_id == user_id, Subscription.status == "active")
        .order_by(Subscription.current_period_end.desc())
        .all()
    )
    return next((item for item in candidates if as_utc(item.current_period_end) > now), None)


@router.get("/plans", response_model=list[PlanOut])
def list_plans():
    return [
        PlanOut(
            code=plan.code, name=plan.name, amount=plan.amount, currency="LKR",
            duration_days=plan.duration_days, features=list(plan.features),
        )
        for plan in PLANS.values()
    ]


@router.post("/checkout", response_model=CheckoutResponse, status_code=status.HTTP_201_CREATED)
def create_checkout(
    payload: CheckoutRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    validate_configuration()
    plan = PLANS[payload.plan_code]
    order_id = f"LFY-{utcnow():%Y%m%d%H%M%S}-{current_user.id}-{uuid4().hex[:10].upper()}"
    payment = Payment(
        user_id=current_user.id, order_id=order_id, provider="payhere", plan_code=plan.code,
        amount=plan.amount, currency="LKR", status="initiated",
    )
    db.add(payment)
    db.commit()

    name_parts = current_user.name.strip().split(maxsplit=1)
    first_name = name_parts[0]
    last_name = name_parts[1] if len(name_parts) > 1 else "-"
    backend_url = settings.BACKEND_PUBLIC_URL.rstrip("/")
    frontend_url = settings.FRONTEND_URL.rstrip("/")
    amount = formatted_amount(plan.amount)
    fields = {
        "merchant_id": settings.PAYHERE_MERCHANT_ID,
        "return_url": f"{frontend_url}/payments/result?order_id={order_id}",
        "cancel_url": f"{frontend_url}/payments/result?order_id={order_id}&cancelled=1",
        "notify_url": f"{backend_url}/payments/notify",
        "first_name": first_name,
        "last_name": last_name,
        "email": current_user.email,
        "phone": payload.phone.strip(),
        "address": payload.address.strip(),
        "city": payload.city.strip(),
        "country": payload.country.strip(),
        "order_id": order_id,
        "items": plan.name,
        "currency": "LKR",
        "amount": amount,
        "custom_1": str(current_user.id),
        "custom_2": plan.code,
        "hash": checkout_hash(
            settings.PAYHERE_MERCHANT_ID, order_id, plan.amount, "LKR", settings.PAYHERE_MERCHANT_SECRET
        ),
    }
    return CheckoutResponse(order_id=order_id, action_url=action_url(), fields=fields)


@router.post("/notify")
async def payment_notification(request: Request, db: Session = Depends(get_db)):
    validate_configuration()
    form = await request.form()
    data = {key: str(value) for key, value in form.items()}
    required = {"merchant_id", "order_id", "payhere_amount", "payhere_currency", "status_code", "md5sig"}
    if not required.issubset(data):
        raise HTTPException(status_code=400, detail="Incomplete PayHere notification")
    if data["merchant_id"] != settings.PAYHERE_MERCHANT_ID:
        raise HTTPException(status_code=400, detail="Invalid merchant ID")
    if not verify_callback_signature(data):
        raise HTTPException(status_code=400, detail="Invalid payment signature")

    payment = (
        db.query(Payment).filter(Payment.order_id == data["order_id"]).with_for_update().first()
    )
    if not payment:
        raise HTTPException(status_code=404, detail="Payment order not found")
    try:
        callback_amount = Decimal(data["payhere_amount"])
    except InvalidOperation as exc:
        raise HTTPException(status_code=400, detail="Invalid payment amount") from exc
    if callback_amount != payment.amount or data["payhere_currency"] != payment.currency:
        raise HTTPException(status_code=400, detail="Payment amount or currency mismatch")

    callback_status = STATUS_MAP.get(data["status_code"])
    if callback_status is None:
        raise HTTPException(status_code=400, detail="Unknown payment status")
    if payment.status == "success" and callback_status != "chargeback":
        db.commit()
        return {"status": "already_processed"}
    if payment.status == "chargeback":
        db.commit()
        return {"status": "already_processed"}

    payment.provider_payment_id = data.get("payment_id") or payment.provider_payment_id
    payment.payment_method = (data.get("method") or "")[:50] or None
    payment.status_message = (data.get("status_message") or "")[:255] or None
    payment.status = callback_status

    if callback_status == "success":
        plan = PLANS[payment.plan_code]
        now = utcnow()
        existing = current_subscription(db, payment.user_id)
        period_base = max(as_utc(existing.current_period_end), now) if existing else now
        if payment.subscription is None:
            db.add(
                Subscription(
                    user_id=payment.user_id, plan_code=payment.plan_code, status="active",
                    current_period_start=now,
                    current_period_end=period_base + timedelta(days=plan.duration_days),
                    source_payment_id=payment.id,
                )
            )
        payment.paid_at = payment.paid_at or now
    elif callback_status == "chargeback" and payment.subscription:
        payment.subscription.status = "cancelled"
        payment.subscription.current_period_end = min(as_utc(payment.subscription.current_period_end), utcnow())

    db.commit()
    return {"status": callback_status}


@router.get("/me", response_model=MyPaymentsOut)
def my_payments(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    subscription = current_subscription(db, current_user.id)
    payments = (
        db.query(Payment).filter(Payment.user_id == current_user.id)
        .order_by(Payment.created_at.desc()).limit(20).all()
    )
    return MyPaymentsOut(
        plan_code=subscription.plan_code if subscription else "free",
        is_premium=subscription is not None,
        subscription=SubscriptionOut.model_validate(subscription) if subscription else None,
        payments=[PaymentOut.model_validate(item) for item in payments],
    )


@router.get("/status/{order_id}", response_model=PaymentStatusOut)
def payment_status(
    order_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    payment = db.query(Payment).filter(
        Payment.order_id == order_id, Payment.user_id == current_user.id
    ).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment order not found")
    return PaymentStatusOut(
        payment=PaymentOut.model_validate(payment),
        subscription=SubscriptionOut.model_validate(payment.subscription) if payment.subscription else None,
    )


@router.get("/admin/transactions", response_model=list[AdminPaymentOut])
def admin_transactions(
    db: Session = Depends(get_db), _: User = Depends(require_admin)
):
    payments = (
        db.query(Payment).options(joinedload(Payment.user))
        .order_by(Payment.created_at.desc()).limit(500).all()
    )
    return [
        AdminPaymentOut(
            **PaymentOut.model_validate(payment).model_dump(), user_id=payment.user_id,
            user_name=payment.user.name, user_email=payment.user.email,
        )
        for payment in payments
    ]
