"""
AI feature routes: doubt-solver chat, note summarizer, quiz generator,
and study planner. All require authentication so usage can be tied to a user.
"""
import json

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.ai.chatbot import solve_doubt
from app.ai.summarizer import summarize_text
from app.ai.quiz_generator import generate_quiz
from app.ai.recommender import generate_study_plan
from app.ai.flashcard_generator import generate_flashcards
from app.config.database import get_db
from app.models.chat import AIChat
from app.models.quiz import Quiz
from app.models.user import User
from app.schemas.ai_schema import (
    ChatRequest,
    ChatResponse,
    SummarizeRequest,
    SummarizeResponse,
    QuizGenerateRequest,
    QuizGenerateResponse,
    QuizQuestion,
    QuizQuestionReview,
    QuizSubmitRequest,
    QuizSubmitResponse,
    StudyPlanRequest,
    StudyPlanResponse,
    Flashcard,
    FlashcardGenerateRequest,
    FlashcardGenerateResponse,
)
from app.services.document_service import extract_text_from_upload
from app.utils.dependencies import get_current_user

router = APIRouter(prefix="/ai", tags=["AI Features"])


@router.post("/chat", response_model=ChatResponse)
def ai_chat(
    payload: ChatRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """AI Doubt Solver — student asks an academic question, AI explains the answer."""
    answer = solve_doubt(payload.question)

    chat_record = AIChat(user_id=current_user.id, question=payload.question, answer=answer)
    db.add(chat_record)
    db.commit()
    db.refresh(chat_record)

    return ChatResponse(question=payload.question, answer=answer, created_at=chat_record.created_at)


@router.post("/summarize", response_model=SummarizeResponse)
def ai_summarize(
    payload: SummarizeRequest,
    current_user: User = Depends(get_current_user),
):
    """AI Note Summarizer — accepts raw text (from a pasted note or extracted PDF) and returns a summary."""
    summary = summarize_text(payload.text, payload.length)
    return SummarizeResponse(summary=summary)


@router.post("/summarize-file", response_model=SummarizeResponse)
def ai_summarize_file(
    file: UploadFile = File(...),
    length: str = Form("medium"),
    current_user: User = Depends(get_current_user),
):
    """Extract text from a TXT/PDF/DOCX file and summarize it."""
    text = extract_text_from_upload(file)
    return SummarizeResponse(summary=summarize_text(text, length))


@router.post("/generate-quiz", response_model=QuizGenerateResponse)
def ai_generate_quiz(
    payload: QuizGenerateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """AI Quiz Generator — generates MCQ questions for a subject/topic, optionally from note text."""
    raw_questions = generate_quiz(
        subject=payload.subject,
        topic=payload.topic,
        num_questions=payload.num_questions,
        source_text=payload.source_text,
        language=payload.language,
    )

    questions = []
    for q in raw_questions:
        record = Quiz(
            user_id=current_user.id,
            subject=payload.subject,
            topic=payload.topic,
            question=q["question"],
            options=json.dumps(q["options"]),
            answer=q["answer"],
        )
        db.add(record)
        db.flush()
        questions.append(
            QuizQuestion(
                id=record.id,
                question=record.question,
                options=q["options"],
            )
        )
    db.commit()

    return QuizGenerateResponse(
        subject=payload.subject,
        topic=payload.topic,
        language=payload.language,
        questions=questions,
    )


@router.post("/quiz/submit", response_model=QuizSubmitResponse)
def submit_quiz(
    payload: QuizSubmitRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Mark a quiz on the server and reveal correct answers only after submission."""
    question_ids = [answer.question_id for answer in payload.answers]
    if len(question_ids) != len(set(question_ids)):
        raise HTTPException(status_code=400, detail="Each quiz question may be answered only once")

    records = (
        db.query(Quiz)
        .filter(Quiz.user_id == current_user.id, Quiz.id.in_(question_ids))
        .all()
    )
    records_by_id = {record.id: record for record in records}
    if len(records_by_id) != len(question_ids):
        raise HTTPException(status_code=404, detail="One or more quiz questions were not found")

    score = 0
    review = []
    for submitted in payload.answers:
        record = records_by_id[submitted.question_id]
        options = json.loads(record.options)
        selected_answer = submitted.selected_answer.strip()
        if selected_answer not in options:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid answer for question {record.id}",
            )
        is_correct = selected_answer == record.answer
        score += int(is_correct)
        review.append(
            QuizQuestionReview(
                question_id=record.id,
                question=record.question,
                options=options,
                selected_answer=selected_answer,
                correct_answer=record.answer,
                is_correct=is_correct,
            )
        )

    total = len(review)
    percentage = round((score / total) * 100, 2)
    return QuizSubmitResponse(
        score=score,
        total=total,
        percentage=percentage,
        review=review,
    )


@router.post("/study-plan", response_model=StudyPlanResponse)
def ai_study_plan(
    payload: StudyPlanRequest,
    current_user: User = Depends(get_current_user),
):
    """AI Study Planner — creates a personalized day-by-day study schedule."""
    plan = generate_study_plan(
        subjects=payload.subjects,
        hours_per_day=payload.hours_per_day,
        days=payload.days,
        goal=payload.goal,
    )
    return StudyPlanResponse(plan=plan)


@router.post("/flashcards", response_model=FlashcardGenerateResponse)
def ai_flashcards(
    payload: FlashcardGenerateRequest,
    current_user: User = Depends(get_current_user),
):
    cards = [Flashcard(**card) for card in generate_flashcards(payload.topic, payload.count)]
    return FlashcardGenerateResponse(topic=payload.topic, cards=cards)
