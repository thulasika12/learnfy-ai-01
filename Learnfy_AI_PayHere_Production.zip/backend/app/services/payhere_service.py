"""PayHere plan pricing, signing, and callback verification."""
import hashlib
import hmac
from dataclasses import dataclass
from decimal import Decimal
from urllib.parse import urlparse

from fastapi import HTTPException

from app.config.settings import settings


@dataclass(frozen=True)
class Plan:
    code: str
    name: str
    amount: Decimal
    duration_days: int | None
    features: tuple[str, ...]


PLANS = {
    "free": Plan("free", "Free", Decimal("0.00"), None, ("Notes and community", "Basic learning tools")),
    "monthly": Plan(
        "monthly", "Monthly Premium", Decimal("500.00"), 30,
        ("All AI learning tools", "Premium access for 30 days", "Priority learning experience"),
    ),
    "yearly": Plan(
        "yearly", "Yearly Premium", Decimal("5000.00"), 365,
        ("All AI learning tools", "Premium access for 365 days", "Save LKR 1,000 per year"),
    ),
}

STATUS_MAP = {"2": "success", "0": "pending", "-1": "cancelled", "-2": "failed", "-3": "chargeback"}


def md5_upper(value: str) -> str:
    return hashlib.md5(value.encode("utf-8"), usedforsecurity=False).hexdigest().upper()


def formatted_amount(amount: Decimal) -> str:
    return f"{amount:.2f}"


def checkout_hash(merchant_id: str, order_id: str, amount: Decimal, currency: str, secret: str) -> str:
    return md5_upper(
        merchant_id + order_id + formatted_amount(amount) + currency + md5_upper(secret)
    )


def callback_signature(
    merchant_id: str, order_id: str, amount: str, currency: str, status_code: str, secret: str
) -> str:
    return md5_upper(merchant_id + order_id + amount + currency + status_code + md5_upper(secret))


def verify_callback_signature(data: dict[str, str]) -> bool:
    expected = callback_signature(
        data.get("merchant_id", ""), data.get("order_id", ""), data.get("payhere_amount", ""),
        data.get("payhere_currency", ""), data.get("status_code", ""), settings.PAYHERE_MERCHANT_SECRET,
    )
    return hmac.compare_digest(expected, data.get("md5sig", "").upper())


def validate_configuration() -> None:
    if not settings.PAYHERE_MERCHANT_ID or not settings.PAYHERE_MERCHANT_SECRET:
        raise HTTPException(status_code=503, detail="PayHere is not configured")
    if not settings.PAYHERE_SANDBOX:
        backend_url = urlparse(settings.BACKEND_PUBLIC_URL)
        if backend_url.scheme != "https" or not backend_url.netloc:
            raise HTTPException(status_code=503, detail="Live PayHere requires a public HTTPS backend URL")


def action_url() -> str:
    return (
        "https://sandbox.payhere.lk/pay/checkout"
        if settings.PAYHERE_SANDBOX
        else "https://www.payhere.lk/pay/checkout"
    )
