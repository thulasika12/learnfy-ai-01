"""API contracts for PayHere checkout and subscription data."""
from datetime import datetime
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class PlanOut(BaseModel):
    code: str
    name: str
    amount: Decimal
    currency: str
    duration_days: int | None
    features: list[str]


class CheckoutRequest(BaseModel):
    plan_code: Literal["monthly", "yearly"]
    phone: str = Field(min_length=7, max_length=30)
    address: str = Field(min_length=3, max_length=255)
    city: str = Field(min_length=2, max_length=100)
    country: str = Field(default="Sri Lanka", min_length=2, max_length=100)


class CheckoutResponse(BaseModel):
    order_id: str
    action_url: str
    fields: dict[str, str]


class PaymentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    order_id: str
    provider_payment_id: str | None
    plan_code: str
    amount: Decimal
    currency: str
    status: str
    payment_method: str | None
    status_message: str | None
    paid_at: datetime | None
    created_at: datetime


class SubscriptionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    plan_code: str
    status: str
    current_period_start: datetime
    current_period_end: datetime


class PaymentStatusOut(BaseModel):
    payment: PaymentOut
    subscription: SubscriptionOut | None = None


class MyPaymentsOut(BaseModel):
    plan_code: str
    is_premium: bool
    subscription: SubscriptionOut | None
    payments: list[PaymentOut]


class AdminPaymentOut(PaymentOut):
    user_id: int
    user_name: str
    user_email: str
